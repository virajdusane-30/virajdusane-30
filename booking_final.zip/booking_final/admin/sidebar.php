<div class="admin-section admin-section1">
    <ul>
        <li><i class="fas fa-sliders-h"></i><a href="admin.php">Dashboard </a><i class="fas admin-dropdown fa-chevron-right"></i></li>
        <li><i class="fas fa-ticket-alt"></i><a href="view.php">Bookings</a> <i class="fas admin-dropdown fa-chevron-right"></i></li>
        
        <li><i class="fas fa-film"></i><a href="addmovie.php">Movies</a> <i class="fas admin-dropdown fa-chevron-right"></i></a></li>
        <li><i class="fas fa-plus-circle"></i><a href="add.php">Add entry</a> <i class="fas admin-dropdown fa-chevron-right"></i></a></li>
        <li><i class="fas fa-id-card"></i><a href="contactus.php">User Feedback</a> <i class="fas admin-dropdown fa-chevron-right"></i></a></li>
        </ul>
</div>
